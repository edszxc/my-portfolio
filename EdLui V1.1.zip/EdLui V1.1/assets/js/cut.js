// Header Init
$('section .cut').each(function() {
	if ($(this).hasClass('cut-top'))
		$(this).css('border-right-width', $(this).parent().width() + "px");
	else if ($(this).hasClass('cut-bottom'))
		$(this).css('border-left-width', $(this).parent().width() + "px");
});

$(document).ready(function(){
	$('#btn-nav').click(function(){
		$(this).toggleClass('open'); 
	}); 

	$('#btn-nav').click(function(){
		if ($('.s-nav').css('margin-left')=='-100px'){
			$('.s-nav').css('margin-left', '+=100px'); 
		}else{
			$('.s-nav').css('margin-left', '-=100px'); 			
		} 
	}); 
});

function collapseSidebar() {
    if ($(".navbar").offset().top > 50) {
        $(".s-nav").addClass("s-nav-scroll");
    } else {
        $(".s-nav").removeClass("s-nav-scroll");
    }
}

$(window).scroll(collapseSidebar);
$(document).ready(collapseSidebar);
